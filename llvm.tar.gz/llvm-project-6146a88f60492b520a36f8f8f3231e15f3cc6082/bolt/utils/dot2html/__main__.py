import dot2html

if __name__ == "__main__":
    dot2html.main()
