#include "stub.h"

void foo() {
  puts("Hello world!\n");
}
