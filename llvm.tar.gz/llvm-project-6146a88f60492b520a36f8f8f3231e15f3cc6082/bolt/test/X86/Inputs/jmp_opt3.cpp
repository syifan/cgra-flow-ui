int f();

int g() { return f(); }
