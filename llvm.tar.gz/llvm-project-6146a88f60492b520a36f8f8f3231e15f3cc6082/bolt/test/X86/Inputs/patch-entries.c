#include "stub.h"

static void foo() { printf("foo\n"); }

int main() {
  foo();
  return 0;
}
