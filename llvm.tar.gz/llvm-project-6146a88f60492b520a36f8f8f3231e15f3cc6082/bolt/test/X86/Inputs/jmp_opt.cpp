int g();

int main() {
  int x = g();
  int y = x*x;
  return y;
}
