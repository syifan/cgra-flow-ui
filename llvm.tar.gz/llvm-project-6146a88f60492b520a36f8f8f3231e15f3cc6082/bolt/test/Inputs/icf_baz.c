#include <stdio.h>

int baz() {
  return 0;
}

