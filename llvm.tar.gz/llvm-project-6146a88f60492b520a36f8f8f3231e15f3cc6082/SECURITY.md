# Reporting LLVM Security Issues

To report security issues in LLVM, please follow the steps outlined on the
[LLVM Security Group](https://llvm.org/docs/Security.html#how-to-report-a-security-issue)
page.
